package com.dashboardnokia.DashboardNokia.controller;

import com.dashboardnokia.DashboardNokia.model.ServerData;
import com.dashboardnokia.DashboardNokia.service.DataService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/v1/server-details")
public class DataController {

    @Autowired
    DataService dataService;

    @GetMapping("/data/{serverName}")
    public List<ServerData> getData(@PathVariable("serverName") String serverName, HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET");
        response.setHeader("Access-Control-Allow-Headers", "X-Requested-With,content-type");
        ServerData[] dataArray = dataService.getData(serverName);
        return Arrays.asList(dataArray);
    }

}
