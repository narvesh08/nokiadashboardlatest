package com.dashboardnokia.DashboardNokia.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServerData {
    @JsonProperty("fs")
    private String fs;
    @JsonProperty("size")
    private String size;
    @JsonProperty("percent")
    private String percent;
    @JsonProperty("color")
    private String color;
    @JsonProperty("mount")
    private String mount;

    public ServerData() {
        // Default constructor required by Jackson
    }
    public ServerData(String size, String color, String fs, String mount, String percent) {
        this.fs = fs;
        this.size = size;
        this.percent = percent;
        this.color = color;
        this.mount = mount;
    }

    public String getFs() {
        return fs;
    }

    public void setFs(String fs) {
        this.fs = fs;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMount() {
        return mount;
    }

    public void setMount(String mount) {
        this.mount = mount;
    }
}
